def func1():
    x = 2
    print x