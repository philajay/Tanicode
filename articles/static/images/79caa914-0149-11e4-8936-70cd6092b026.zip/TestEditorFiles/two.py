#fgwerhwf
import three

def add(x,y):
    print x + y
    return x + y

def c():
    three.func1()