import two

x = two.add(3,4)
two.c()

print 'coool'